package Tarleton.ReceiptRecorder;

import java.math.BigDecimal;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class ReceiptDTO {
    
    private Long id;
    private String storeName;
    private BigDecimal price;
    private String datePurchased;
    private String description; 


    public ReceiptDTO() {
    }

    public ReceiptDTO(Receipt receipt){
        this.id = receipt.getId();
        this.storeName = receipt.getStoreName();
        this.price = receipt.getPrice();
        this.datePurchased = receipt.getDatePurchased();
        this.description = receipt.getDescription();
    }
    
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getStoreName() {
        return storeName;
    }

    public void setStoreName(String storeName) {
        this.storeName = storeName;
    }

    public BigDecimal getPrice() {
        return price;
    }

    public void setPrice(BigDecimal price) {
        this.price = price;
    }

    public String getDatePurchased() {
        return datePurchased;
    }

    public void setDatePurchased(String datePurchased) {
        this.datePurchased = datePurchased;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }
    
    
    
}
