
package Tarleton.ReceiptRecorder;

import java.util.List;
import javax.ejb.EJB;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.UriInfo;


@Path("")
public class ReceiptWS {
    
    @Context
    private UriInfo context;
    @EJB
    private ReceiptService receiptService;
    
    @GET
    @Path("receipt/{receiptId}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response readOrder(@PathParam("receiptId") Long id) {
        Receipt rec = receiptService.selectById(id);
        if (rec == null){
            return Response.status(Response.Status.NO_CONTENT).build();
        }
        ReceiptDTO dto = new ReceiptDTO(rec);
        return Response.ok(rec).build();
    }
    
    @GET
    @Path("receipts")
    @Produces(MediaType.APPLICATION_JSON)
    public Response readOrders() {
        List<Receipt> recs = receiptService.selectAll();
        ReceiptDTO[] p =  new ReceiptDTO[recs.size()];
        int i = 0;
        for (Receipt rec: recs){
            p[i] = new ReceiptDTO(rec);
            i++;
        }
        return Response.ok(p).build();
    }
    
    @POST
    @Path("addReceipt")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.TEXT_PLAIN)
    public Response createOrder(AddReceipt receipt){
        Receipt receiptE = new Receipt();
        receiptE.setStoreName(receipt.getStoreName());
        receiptE.setPrice(receipt.getPrice());
        receiptE.setDatePurchased(receipt.getDate());
        receiptE.setDescription(receipt.getDescription());
        receiptService.persist(receiptE);
        return Response.ok(receiptE.getId()).build();
    }
    
    @POST
    @Path("delete/{receiptId}")
    @Produces(MediaType.TEXT_PLAIN)
    public Response deleteOrder(@PathParam("receiptId") Long id){
        List<Receipt> receipts = receiptService.selectAll();
        for(Receipt r : receipts){
            if (r.getId() == id){
                receiptService.remove(r);
            }
        }
        return Response.ok("Good job").build();
    }
}
