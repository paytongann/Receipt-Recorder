package Tarleton.ReceiptRecorder;

import java.util.List;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

@Stateless
public class ReceiptService {
    
    @PersistenceContext
    private EntityManager em;
    
    public Receipt selectById(Long id){
        return em.find(Receipt.class, id);
    }    
    
    public List<Receipt> selectAll(){
        TypedQuery<Receipt> r = em.createQuery("select o from receipts o", Receipt.class);
        return r.getResultList();
    }
    
    public void persist(Receipt rec){
        em.persist(rec);
    }
    
    public void update(Receipt rec){
        em.merge(rec);
    }
    
    public void remove(Receipt receipt){
        if(!em.contains(receipt)){
            receipt = em.merge(receipt);
        }
        em.remove(receipt);
    }
}
